Welcome to Email Cleaner!

This tool helps in managing and deleting emails efficiently. To use:
- Locate the 'dist folder' and open it.
- Right click on 'email_cleaner.exe' and create shortcut for your Desktop
- Double-click 'email_cleaner.exe' to launch the application.
- Follow the on-screen instructions to proceed.
